const form = document.getElementById("form");
const btnPrice = document.getElementById("btn-calc");

function isAlphabetic(s) {
  /* TODO */
}

function removeSpaces(s) {
  /* TODO */
}

function isPhone(s) {
  /* TODO */
}

/*
Pizza prices
-------------

  Personal 	$11.55
  Medium 	    $15.25
  Large 	    $22.00
  X-Large 	$25.00

  Toppings
  Each        $1.79
*/
function calcPrice() {
  let price = 0;
  /* TODO */
  return price;
}

function calcPriceClicked() {
  /* TODO */
}

function orderPizzaClicked(ev) {
  ev.preventDefault();
  /* TODO */
}

/* TODO : attach event listeners */
