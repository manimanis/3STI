/* TODO Calculate the resistor value */
